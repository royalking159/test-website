# That's Entertainment (Pilot)

- Show: Hazbin Hotel
- Special
- Aired: Oct 28, 2019
