# Weapon of Mass Distraction

- Show: Hazbin Hotel
- Season 2, Episode 7
- Aired: Nov 19, 2025
