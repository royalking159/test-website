# Behind Closed Doors

- Show: Hazbin Hotel
- Season 2, Episode 3
- Aired: Nov 5, 2025
