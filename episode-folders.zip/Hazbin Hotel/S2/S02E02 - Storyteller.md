# Storyteller

- Show: Hazbin Hotel
- Season 2, Episode 2
- Aired: Oct 29, 2025
