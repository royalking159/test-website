# New Pentious

- Show: Hazbin Hotel
- Season 2, Episode 1
- Aired: Oct 29, 2025
