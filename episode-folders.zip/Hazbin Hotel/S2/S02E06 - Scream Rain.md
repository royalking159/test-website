# Scream Rain

- Show: Hazbin Hotel
- Season 2, Episode 6
- Aired: Nov 12, 2025
