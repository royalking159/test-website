# Silenced

- Show: Hazbin Hotel
- Season 2, Episode 5
- Aired: Nov 12, 2025
