# Overture

- Show: Hazbin Hotel
- Season 1, Episode 1
- Aired: Jan 19, 2024
