# Masquerade

- Show: Hazbin Hotel
- Season 1, Episode 4
- Aired: Jan 19, 2024
