# Radio Killed the Video Star

- Show: Hazbin Hotel
- Season 1, Episode 2
- Aired: Jan 19, 2024
