# Scrambled Eggs

- Show: Hazbin Hotel
- Season 1, Episode 3
- Aired: Jan 19, 2024
