# Dad Beat Dad

- Show: Hazbin Hotel
- Season 1, Episode 5
- Aired: Jan 26, 2024
