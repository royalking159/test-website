# Welcome to Heaven

- Show: Hazbin Hotel
- Season 1, Episode 6
- Aired: Jan 26, 2024
