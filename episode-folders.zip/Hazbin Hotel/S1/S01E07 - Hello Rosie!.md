# Hello Rosie!

- Show: Hazbin Hotel
- Season 1, Episode 7
- Aired: Feb 2, 2024
