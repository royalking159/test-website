# The Harvest Moon Festival

- Show: Helluva Boss
- Season 1, Episode 5
- Aired: Apr 30, 2021
