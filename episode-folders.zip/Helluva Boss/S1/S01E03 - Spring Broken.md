# Spring Broken

- Show: Helluva Boss
- Season 1, Episode 3
- Aired: Jan 31, 2021
