# Queen Bee

- Show: Helluva Boss
- Season 1, Episode 8
- Aired: Jun 24, 2023
