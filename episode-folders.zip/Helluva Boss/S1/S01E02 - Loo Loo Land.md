# Loo Loo Land

- Show: Helluva Boss
- Season 1, Episode 2
- Aired: Dec 9, 2020
