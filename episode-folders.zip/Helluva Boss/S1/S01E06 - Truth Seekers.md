# Truth Seekers

- Show: Helluva Boss
- Season 1, Episode 6
- Aired: Aug 21, 2021
