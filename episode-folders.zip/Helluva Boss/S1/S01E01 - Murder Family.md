# Murder Family

- Show: Helluva Boss
- Season 1, Episode 1
- Aired: Oct 31, 2020
