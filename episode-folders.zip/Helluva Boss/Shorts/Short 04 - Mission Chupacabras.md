# Mission: Chupacabras

- Show: Helluva Boss
- Short 4
- Aired: Sep 29, 2024
