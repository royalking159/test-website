# Mission: Bigfoot

- Show: Helluva Boss
- Short 9
- Aired: Mar 7, 2026
