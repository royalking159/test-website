# Mission: Bad Drivezo

- Show: Helluva Boss
- Short 6
- Aired: Aug 2, 2025
