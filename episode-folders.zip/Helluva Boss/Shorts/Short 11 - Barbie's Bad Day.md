# Barbie's Bad Day

- Show: Helluva Boss
- Short 11
- Aired: Apr 25, 2026
