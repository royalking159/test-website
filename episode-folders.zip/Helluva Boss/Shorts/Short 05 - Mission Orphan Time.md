# Mission: Orphan Time

- Show: Helluva Boss
- Short 5
- Aired: Jun 28, 2025
