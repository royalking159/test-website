# Mission: Whacked Off

- Show: Helluva Boss
- Short 7
- Aired: Sep 6, 2025
