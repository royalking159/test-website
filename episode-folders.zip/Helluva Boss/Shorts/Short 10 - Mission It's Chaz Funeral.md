# Mission: It's Chaz Funeral

- Show: Helluva Boss
- Short 10
- Aired: Apr 1, 2026
