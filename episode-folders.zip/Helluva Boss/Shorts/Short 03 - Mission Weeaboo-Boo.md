# Mission: Weeaboo-Boo

- Show: Helluva Boss
- Short 3
- Aired: Aug 31, 2024
