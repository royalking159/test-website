# Oops

- Show: Helluva Boss
- Season 2, Episode 6
- Aired: Sep 9, 2023
