# Ghostf**ckers

- Show: Helluva Boss
- Season 2, Episode 10
- Aired: Oct 31, 2024
