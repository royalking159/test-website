# The Full Moon

- Show: Helluva Boss
- Season 2, Episode 8
- Aired: May 31, 2024
