# Mastermind

- Show: Helluva Boss
- Season 2, Episode 11
- Aired: Nov 29, 2024
