# Mammon's Magnificent Musical Mid-Season Special (ft Fizzarolli)

- Show: Helluva Boss
- Season 2, Episode 7
- Aired: Oct 29, 2023
