# Western Energy

- Show: Helluva Boss
- Season 2, Episode 4
- Aired: May 20, 2023
