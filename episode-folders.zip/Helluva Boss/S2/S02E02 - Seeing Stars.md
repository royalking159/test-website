# Seeing Stars

- Show: Helluva Boss
- Season 2, Episode 2
- Aired: Oct 19, 2022
