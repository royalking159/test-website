# Sinsmas

- Show: Helluva Boss
- Season 2, Episode 12
- Aired: Dec 21, 2024
